﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MatrixCalculator : MonoBehaviour
{
    public GameObject answerSheet;
    public GameObject matrix1;
    public GameObject matrix2;
    public GameObject typeChanger;
    public GameObject detAnswer;
    


    bool multiM;
    bool sumM;
    public Button findInv_Btn;
    public Button sumB;
    public Button multiB;
    bool isInverseSelected = false;

    ///matrix X
    float x11 = 0f; float x12 = 0f; float x13 = 0f;
    float x21 = 0f; float x22 = 0f; float x23 = 0f;
    float x31 = 0f; float x32 = 0f; float x33 = 0f;

    ///matrix Y
    float y11 = 0f; float y12 = 0f; float y13 = 0f;
    float y21 = 0f; float y22 = 0f; float y23 = 0f;
    float y31 = 0f; float y32 = 0f; float y33 = 0f;

    ///Answer Matrix
    float ans11; float ans12; float ans13;
    float ans21; float ans22; float ans23;
    float ans31; float ans32; float ans33;
    float detA;

    private void Start()
    {
        TypeSelecter_Sum();
    }

    void AssignMarix()
    {
        AssignX(); AssignY();
    }
    public void AssignX()
    {
        x11 = float.Parse(GameObject.Find("a11").GetComponent<TMP_InputField>().text);
        x12 = float.Parse(GameObject.Find("a12").GetComponent<TMP_InputField>().text);
        x13 = float.Parse(GameObject.Find("a13").GetComponent<TMP_InputField>().text);
        x21 = float.Parse(GameObject.Find("a21").GetComponent<TMP_InputField>().text);
        x22 = float.Parse(GameObject.Find("a22").GetComponent<TMP_InputField>().text);
        x23 = float.Parse(GameObject.Find("a23").GetComponent<TMP_InputField>().text);
        x31 = float.Parse(GameObject.Find("a31").GetComponent<TMP_InputField>().text);
        x32 = float.Parse(GameObject.Find("a32").GetComponent<TMP_InputField>().text);
        x33 = float.Parse(GameObject.Find("a33").GetComponent<TMP_InputField>().text);
    }
    public void AssignY()
    {
        y11 = float.Parse(GameObject.Find("b11").GetComponent<TMP_InputField>().text);
        y12 = float.Parse(GameObject.Find("b12").GetComponent<TMP_InputField>().text);
        y13 = float.Parse(GameObject.Find("b13").GetComponent<TMP_InputField>().text);
        y21 = float.Parse(GameObject.Find("b21").GetComponent<TMP_InputField>().text);
        y22 = float.Parse(GameObject.Find("b22").GetComponent<TMP_InputField>().text);
        y23 = float.Parse(GameObject.Find("b23").GetComponent<TMP_InputField>().text);
        y31 = float.Parse(GameObject.Find("b31").GetComponent<TMP_InputField>().text);
        y32 = float.Parse(GameObject.Find("b32").GetComponent<TMP_InputField>().text);
        y33 = float.Parse(GameObject.Find("b33").GetComponent<TMP_InputField>().text);
    }

    public void Calculate()
    {
        AssignMarix();

        if (multiM == true && sumM == false)
        {
            ans11 = ((x11 * y11) + (x12 * y21) + (x13 * y31));
            ans12 = ((x11 * y12) + (x12 * y22) + (x13 * y32));
            ans13 = ((x11 * y13) + (x12 * y23) + (x13 * y33));

            ans21 = ((x21 * y11) + (x22 * y21) + (x23 * y31));
            ans22 = ((x21 * y12) + (x22 * y22) + (x23 * y32));
            ans23 = ((x21 * y13) + (x22 * y23) + (x23 * y33));

            ans31 = ((x31 * y11) + (x32 * y21) + (x33 * y31));
            ans32 = ((x31 * y12) + (x32 * y22) + (x33 * y32));
            ans33 = ((x31 * y13) + (x32 * y23) + (x33 * y33));
        }else if (multiM == false && sumM == true)
        {
            ans11 = x11 + y11; ans12 = x12 + y12; ans13 = x13 + y13;
            ans21 = x21 + y21; ans22 = x22 + y22; ans23 = x23 + y23;
            ans31 = x31 + y31; ans32 = x32 + y32; ans33 = x33 + y33;

        }

        AnswerSheet();

    }

    public void AssignAsA()
    {
        GameObject.Find("a11").GetComponent<TMP_InputField>().text = ans11.ToString();
        GameObject.Find("a12").GetComponent<TMP_InputField>().text = ans12.ToString();
        GameObject.Find("a13").GetComponent<TMP_InputField>().text = ans13.ToString();
        GameObject.Find("a21").GetComponent<TMP_InputField>().text = ans21.ToString();
        GameObject.Find("a22").GetComponent<TMP_InputField>().text = ans22.ToString();
        GameObject.Find("a23").GetComponent<TMP_InputField>().text = ans23.ToString();
        GameObject.Find("a31").GetComponent<TMP_InputField>().text = ans31.ToString();
        GameObject.Find("a32").GetComponent<TMP_InputField>().text = ans32.ToString();
        GameObject.Find("a33").GetComponent<TMP_InputField>().text = ans33.ToString();
    }
    public void AssignAsB()
    {
        GameObject.Find("b11").GetComponent<TMP_InputField>().text = ans11.ToString();
        GameObject.Find("b12").GetComponent<TMP_InputField>().text = ans12.ToString();
        GameObject.Find("b13").GetComponent<TMP_InputField>().text = ans13.ToString();
        GameObject.Find("b21").GetComponent<TMP_InputField>().text = ans21.ToString();
        GameObject.Find("b22").GetComponent<TMP_InputField>().text = ans22.ToString();
        GameObject.Find("b23").GetComponent<TMP_InputField>().text = ans23.ToString();
        GameObject.Find("b31").GetComponent<TMP_InputField>().text = ans31.ToString();
        GameObject.Find("b32").GetComponent<TMP_InputField>().text = ans32.ToString();
        GameObject.Find("b33").GetComponent<TMP_InputField>().text = ans33.ToString();
    }

    public void ClearMatrix()
    {
        ClearMatrixA();
        ClearMatrixB();
    }
    public void ClearMatrixA()
    {
        GameObject.Find("a11").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("a12").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("a13").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("a21").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("a22").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("a23").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("a31").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("a32").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("a33").GetComponent<TMP_InputField>().text = null;
    }
    public void ClearMatrixB()
    {
        GameObject.Find("b11").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("b12").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("b13").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("b21").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("b22").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("b23").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("b31").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("b32").GetComponent<TMP_InputField>().text = null;
        GameObject.Find("b33").GetComponent<TMP_InputField>().text = null;
    }

    public void TypeSelecter_Sum()
    {
        sumM = true;
        multiM = false;
        sumB.interactable = false;
        multiB.interactable = true;
    }
    public void TypeSelecter_Multi()
    {
        sumM = false;
        multiM = true;
        sumB.interactable = true;
        multiB.interactable = false;       
    }


    public void SelectInverse()
    {
        if(isInverseSelected == false)
        {
            isInverseSelected = true;
            matrix2.SetActive(false);
            typeChanger.SetActive(false);
            findInv_Btn.interactable = true;

        }
        else if (isInverseSelected == true)
        {
            isInverseSelected = false;
            matrix2.SetActive(true);
            typeChanger.SetActive(true);
            findInv_Btn.interactable = false;

        }
    }
    public void Determinate_Calc()
    {
        Determinate();
        detAnswer.SetActive(true);
        GameObject.Find("ansDet_txt").GetComponent<TMP_InputField>().text =
            detA.ToString();
    }
    void Determinate()
    {
        AssignX();
        detA = x11 * ((x22 * x33) - (x32 * x23)) -
               x12 * ((x21 * x33) - (x31 * x23)) +
               x13 * ((x21 * x32) - (x31 * x22));

    }
    public void Calc_InverseMatrix()
    {
        AssignX();
        Determinate();
        

        ans11 = ((x22 * x33) - (x32 * x23)) * (1 / detA);
        ans12 = ((x32 * x13) - (x12 * x33)) * (1 / detA);
        ans13 = ((x12 * x23) - (x22 * x13)) * (1 / detA);
        ans21 = ((x23 * x31) - (x33 * x21)) * (1 / detA);
        ans22 = ((x33 * x11) - (x13 * x31)) * (1 / detA);
        ans23 = ((x13 * x21) - (x23 * x11)) * (1 / detA);
        ans31 = ((x21 * x32) - (x31 * x22)) * (1 / detA);
        ans32 = ((x31 * x12) - (x11 * x32)) * (1 / detA);
        ans33 = ((x11 * x22) - (x21 * x12)) * (1 / detA);
        AnswerSheet();
    }

    void AnswerSheet()
    {
        answerSheet.SetActive(true);
        GameObject.Find("ao11").GetComponent<TMP_InputField>().text = ans11.ToString();
        GameObject.Find("ao12").GetComponent<TMP_InputField>().text = ans12.ToString();
        GameObject.Find("ao13").GetComponent<TMP_InputField>().text = ans13.ToString();
        GameObject.Find("ao21").GetComponent<TMP_InputField>().text = ans21.ToString();
        GameObject.Find("ao22").GetComponent<TMP_InputField>().text = ans22.ToString();
        GameObject.Find("ao23").GetComponent<TMP_InputField>().text = ans23.ToString();
        GameObject.Find("ao31").GetComponent<TMP_InputField>().text = ans31.ToString();
        GameObject.Find("ao32").GetComponent<TMP_InputField>().text = ans32.ToString();
        GameObject.Find("ao33").GetComponent<TMP_InputField>().text = ans33.ToString();
    }
}
////finally finished #line 232 ///