﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Trigonometry : MonoBehaviour
{
    public TMP_Dropdown tri;
    public TMP_Dropdown tri_I;
    public TMP_Dropdown units;

    public TMP_InputField triX;
    public TMP_InputField tri_IX;
    public TMP_InputField answerTN;
    public TMP_InputField answerTI;


    public float ansTN , finalAnsTN , tri_value , triDegree;
    [HideInInspector]
    public float ansTI, finalAnsTI , triI_value;

    void Update()
    {
        tri_value = float.Parse(triX.text);
        triI_value = float.Parse(tri_IX.text);

        if (units.value == 1)
        {
            triDegree = (tri_value * Mathf.Deg2Rad);
            finalAnsTI = (ansTI * Mathf.Rad2Deg);
            finalAnsTN = ansTN;
        }
        else if (units.value == 0)
        {
            finalAnsTN = ansTN;
            finalAnsTI = ansTI;
        }

        if (triX.text != "")
        {
            if (units.value == 1)
            {
                Tri_NDegree();
            }
            else {
                Tri_N();
            }
            
            answerTN.text = finalAnsTN.ToString();
        }

        if (tri_IX.text != "")
        {
            Tri_I();
            answerTI.text = finalAnsTI.ToString();
        }
    }

    public void Tri_N()
    {

        if (tri.value == 0)
        {
            ansTN = Mathf.Sin(tri_value);
        }else if (tri.value == 1)
        {
            ansTN = Mathf.Cos(tri_value);
        }else if (tri.value == 2)
        {
            ansTN = Mathf.Tan(tri_value);
        }else if (tri.value == 3)
        {
            ansTN = 1 / Mathf.Tan(tri_value);
        }else if (tri.value == 4)
        {
            ansTN = 1/ Mathf.Cos(tri_value);
        }else if (tri.value == 5)
        {
            ansTN =  1 / Mathf.Sin(tri_value);
        }
    }

    public void Tri_NDegree()
    {

        if (tri.value == 0)
        {
            ansTN = Mathf.Sin(triDegree);
        }
        else if (tri.value == 1)
        {
            ansTN = Mathf.Cos(triDegree);
        }
        else if (tri.value == 2)
        {
            ansTN = Mathf.Tan(triDegree);
        }
        else if (tri.value == 3)
        {
            ansTN = 1 / Mathf.Tan(triDegree);
        }
        else if (tri.value == 4)
        {
            ansTN = 1 / Mathf.Cos(triDegree);
        }
        else if (tri.value == 5)
        {
            ansTN = 1 / Mathf.Sin(triDegree);
        }
    }

    public void Tri_I()
    {
        if (tri_I.value == 0)
        {
            ansTI = Mathf.Asin(triI_value);
        }
        else if (tri_I.value == 1)
        {
            ansTI = Mathf.Acos(triI_value);
        }
        else if (tri_I.value == 2)
        {
            ansTI = Mathf.Atan(triI_value);
        }
        else if (tri_I.value == 3)
        {
            ansTI = (Mathf.PI / 2) - Mathf.Atan(triI_value);
        }
        else if (tri_I.value == 4)
        {
            ansTI = (Mathf.PI / 2) - Mathf.Asin(1 / triI_value);
        }
        else if (tri_I.value == 5)
        {
            ansTI = Mathf.Asin( 1 / triI_value);
        }
    }
}
