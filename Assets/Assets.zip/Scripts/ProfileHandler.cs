﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Firebase.Auth;
using Firebase.Firestore;
using Firebase.Database;

public class ProfileHandler : MonoBehaviour
{
    [Header("Profile Data")]
    [SerializeField] TextMeshProUGUI usernameText;

    DatabaseReference reference;
    FirebaseUser user;
    public void Start()
    {

        FirebaseDatabase.DefaultInstance.GetReference("Users").GetValueAsync()
            .ContinueWith(task =>
            {
                if (task.IsCompleted)
                {
                    DataSnapshot snapshot = task.Result;
                    foreach (DataSnapshot user in snapshot.Children)
                    {
                        IDictionary dictUser = (IDictionary)user.Value;
                        Debug.Log("" + dictUser["Email"] + " - " + dictUser["Username"]);
                    };
                }
            });
    }
}
