﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class NumPowers : MonoBehaviour
{
    public Button nType, n_1Type;
    public TMP_InputField nObj, xObj, ansObj;

    public float x, n, ans;

    public bool nBool = true;
    private void Start()
    {
        ans = 0f;
    }

    public void Update()
    {
        if (xObj.text == ""){
            x = 0f; }
        if (nObj.text == ""){
            n = 1f; }


        x = float.Parse(xObj.text);
        n = float.Parse(nObj.text);

        if (nBool == true)
        {
            ans = Mathf.Pow(x, n);
        }
        else if (nBool == false)
        {
            ans = Mathf.Pow(x, (1 / n));
        }
        ansObj.text = ans.ToString();
    }

    public void typeChange()
    {
        if (nBool == true)
        {
            nBool = false;
            nType.interactable = true;
            n_1Type.interactable = false;
        }
        else if (nBool == false)
        {
            nBool = true;
            nType.interactable = false;
            n_1Type.interactable = true;
        }
    }
}
