﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Firebase.Auth;
using Firebase.Database;
using TMPro;

public class AuthSystem : MonoBehaviour
{
    [Header("Sign Up")]
    [SerializeField]
    GameObject signUpPage;
    [SerializeField]
    TMP_InputField username;
    [SerializeField]
    TMP_InputField email;
    [SerializeField]
    TMP_InputField password;
    [SerializeField]
    TMP_InputField conPassword;

    [Header("LogIn")]
    [SerializeField] GameObject logInpage;
    [SerializeField] TMP_InputField logEmail;
    [SerializeField] TMP_InputField logPass;

    FirebaseAuth auth;
    DatabaseReference reference;

    private void Start()
    {
        auth = FirebaseAuth.DefaultInstance;
        reference = FirebaseDatabase.DefaultInstance.RootReference;
    }
    public void SignUp()
    {
        if (username.text == "" || password.text == "" || email.text == "")
        {
            username.text = "Fill All Details Correctlly";
            return;
        }

        if (password.text != conPassword.text)
        {
            conPassword.text = "Password Doesn't Match !";
        }
        auth.CreateUserWithEmailAndPasswordAsync(email.text, password.text).
             ContinueWith(task =>
             {
                 if (task.IsCanceled)
                 {
                     Debug.Log("Operation Cancelled");
                     return;
                 }
                 if (task.IsFaulted)
                 {
                     Debug.Log("Operation Errored");
                     password.text = "Failed to SignUp Try Again !";
                     return;
                 }
                 FirebaseUser newuser = task.Result;
                 Debug.LogFormat("Firebase user created successfully: {0} ({1})",
      newuser.DisplayName, newuser.UserId);
                 signUpPage.SetActive(false);
                 
             });

        User user = new User();

        user.Username = username.text;
        user.Email = email.text;
        user.Profession = "";

        string json = JsonUtility.ToJson(user);
        reference.Child("Users").Child(user.Username).SetRawJsonValueAsync(json)
            .ContinueWith(task =>
            {
                if (task.IsCompleted)
                {
                    Debug.Log("Data Synced");
                }
                else
                {
                    Debug.Log("Failed To Sync");
                }
            }
            );
    }

    public void LogIn()
    {
        auth.SignInWithEmailAndPasswordAsync(logEmail.text, logPass.text)
            .ContinueWith(task =>
            {
                if (task.IsCompleted)
                {
                    Debug.Log("Log In Successful");
                    logInpage.SetActive(false);
                }
                else
                {
                    Debug.Log("Error in Log In");
                }
            });
    }

    public void SignOut()
    {
        auth.SignOut();
    }
}
