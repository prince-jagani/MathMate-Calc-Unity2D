﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuScrollManager : MonoBehaviour
{
    public RectTransform contentRect;
    public ScrollRect scrollRect;
    public float modeCount;

    public float posY;
    float maxPosY; 

    void Update()
    {
        posY = contentRect.localPosition.y;
        maxPosY = (modeCount * 300) + 250;

        if (posY < -150 || posY > maxPosY)
        {
            scrollRect.movementType = ScrollRect.MovementType.Elastic;
            scrollRect.elasticity = 0.25f;
        } else
        {
            scrollRect.movementType = ScrollRect.MovementType.Unrestricted;
        }
    }
}
